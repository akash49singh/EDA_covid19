TEAM 29 (Data Analysis)

Topic - Exploratory Data Analysis of COVID-19 in India.

Step 1 -: Data source - https://www.kaggle.com/sudalairajkumar/covid19-in-india

Step 2 -: Google colab link - https://colab.research.google.com/drive/1LaccstxEd8fVx4rYkUXf29tLHHj3Xvm-#scrollTo=eb0bd854

Step 3 -: Website - https://covidashindia.herokuapp.com/
